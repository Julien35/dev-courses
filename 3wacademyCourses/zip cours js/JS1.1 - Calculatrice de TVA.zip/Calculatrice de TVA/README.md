## Enoncé

L'utilisateur saisit un montant HT, le résultat TTC s'affiche en HTML.

## Détails

* Le taux de TVA utilisé est le taux normal en vigueur en France, il ne bouge pas.
* Il faut réafficher toutes les informations : le montant HT, le montant de TVA et le résultat TTC.
* Attention au type de la donnée renvoyé par *window.prompt()* !
* Le montant HT peut être à virgule...
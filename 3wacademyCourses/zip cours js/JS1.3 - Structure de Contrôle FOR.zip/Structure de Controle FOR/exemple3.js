// Déclaration d'une variable.
var compteur;


/*
 * Boucle comptant de 20 à 1 inclus.
 *
 *
 * La structure de contrôle for possède trois parties :
 *
 * for(INITIALISATION; COMPARAISON; MISE A JOUR)
 * {
 *     // ...
 * }
 */
for(compteur = 20; compteur >= 1; compteur--)
{
    document.write('<p>Le compteur vaut <strong>' + compteur + '</strong>.</p>');
}

// Sans cette boucle il aurait fallu écrire manuellement dix fois la ligne 20.
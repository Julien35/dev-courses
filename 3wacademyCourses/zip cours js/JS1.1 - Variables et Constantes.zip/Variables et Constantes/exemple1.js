// Déclaration d'une variable.
var firstVariable;


// Affectation d'une valeur à la variable.
firstVariable = 'Bonjour tout le monde !';

// Affichage du contenu de la variable directement dans la page HTML.
document.write(firstVariable);

$(document).ready(function(){
	

	var maze = new Maze(maze_one);


	
	maze.display();
	
	console.log(JSON.stringify(maze));
	
	var player = maze.newPlayer({
		img: 'hitler.png'
	});


	setTimeout(function(){
		
		solve(player, maze, 50);
			
	}, 1000);
	

});



function solve(player, maze, i){
	if(i < 0) return;
	if(player.position.i == maze.END.i && player.position.j == maze.END.j) {
		alert('YOU WIN !');
		return;
	}
	
	
	//SOLVE THE MAZE HERE USING maze.forward(player), maze.left(player) and maze.right(player)
	//Functions above return true or false if movement succeded



	setTimeout(function(){
		solve(player, maze, --i);
	}, 300);
}
## Mario

Solve a maze step by step
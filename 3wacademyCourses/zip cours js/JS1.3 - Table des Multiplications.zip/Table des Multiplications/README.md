## Enoncé

Construire une table des multiplications dans une variable puis afficher en HTML le contenu de cette variable.

## Détails

* Pour rappel, une boucle permet d'initialiser un tableau...
* Il faut utiliser un tableau HTML pour construire l'affichage
* Pour l'affichage HTML, lorsque le nombre est multiplié par lui-même (1x1, 2x2, 3x3, etc.), la cellule du tableau doit s'afficher d'une autre couleur que les autres cellules. **La solution doit être en CSS**.
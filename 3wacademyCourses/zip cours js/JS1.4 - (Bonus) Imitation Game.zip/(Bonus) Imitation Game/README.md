## Enoncé

Des chaînes de caractères sont affichée en HTML.

Il faut utiliser des fonctions déjà écrites en JavaScript pour générer dans une variable les même chaînes de caractères qui sont affichées en HTML. Puis il faut afficher cette variable dans la console du navigateur web.

Le tout en écrivant le moins de code possible !

## Détails

* Interdiction de modifier le code des 3 fonctions déjà existantes.
* Utiliser la variable *result* dans le code principal pour générer les chaînes de caractères.
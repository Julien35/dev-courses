## Enoncé

La date du jour s'affiche dynamiquement en HTML sous la forme “Nous sommes le Mardi 11 Février 2014”.

## Ressources

* [Classe Date dans DevDocs.io](http://devdocs.io/javascript/global_objects/date)

## Détails

* La classe *Date* possède une méthode pour extraire chaque partie de la date et de l'heure
* Attention aux valeurs renvoyées par chaque méthode, bien lire la documentation
* Il va falloir se servir de tableaux pour afficher en français les noms des jours de la semaine et des mois...
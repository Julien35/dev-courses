## INSTRUCTIONS
Initiation à Worpress

## HTML
- Utilisation de wordpress pour la réalisation de ce site

## CSS
- Utilisation de flexbox
- Utilisation du responsive
- Largeur limité à 75% maximum
- Taille de la police :
    - par défaut : 1em
- Police utilisés :
    - Titre : "Amaranth"
    - Texte : "Open Sans"

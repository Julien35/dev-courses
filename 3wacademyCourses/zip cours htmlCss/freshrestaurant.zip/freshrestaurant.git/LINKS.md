
# Liens utile
- [Polices personnalisées avec @font-face](http://css-tricks.com/snippets/css/using-font-face/)
- [Pseudo-élements et propriété content](http://www.smashingmagazine.com/2011/07/13/learning-to-use-the-before-and-after-pseudo-elements-in-css/)
- [La technique du reset CSS](http://www.alsacreations.com/astuce/lire/36-reset-css.html)
- [Reset CSS par Eric Meyer](http://meyerweb.com/eric/tools/css/reset/)
- [Normalize CSS par Nicolas Gallagher et Jonathan Neal](https://github.com/necolas/normalize.css/)
- [Modèle de boîte border-box](http://css-tricks.com/box-sizing/)


# Aller plus loin

- [Italique VS Oblique](http://en.wikipedia.org/wiki/Oblique_type)
- [Border-box partout](http://www.paulirish.com/2012/box-sizing-border-box-ftw/)
- [La méthode SMACCS +](http://nicoespeon.com/fr/2013/05/tombez-pour-smacss/)

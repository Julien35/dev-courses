## Les pseudo-éléments
https://developer.mozilla.org/fr/docs/Web/CSS/Pseudo-%C3%A9l%C3%A9ments

## Les pseudo classes
https://developer.mozilla.org/fr/docs/Web/CSS/pseudo-classes

## La propriété content
https://developer.mozilla.org/fr/docs/Web/CSS/content

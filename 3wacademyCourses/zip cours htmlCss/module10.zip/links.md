## Les dégradés en CSS
https://developer.mozilla.org/fr/docs/Web/CSS/gradient
http://www.colorzilla.com/gradient-editor/

## L'audio en HTML
https://developer.mozilla.org/fr/docs/Web/HTML/Element/audio

## La vidéo en HTML
https://developer.mozilla.org/fr/docs/Web/HTML/Element/Video

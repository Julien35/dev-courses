# INSTRUCTIONS
Découverte du inline-block

## HTML
- Utilisation du inline-block pour le placement de certains éléments
- Utilisation du float pour quelques éléments
- Utilisation du reset.css ou du normalize.css


## CSS
- Largeur limité entre 800px et 1100px
- Largeur du bloc gauche : 69%
- Largeur du bloc de droite : 30%
- Utiliser une class pour limiter intelligemment le contenu
- Taille de la police :
    - par défaut : 1em
    - titres :  2em
- Police utilisés :
    - "Slabo 27px"

## BONUS
- Trouver comment on réalise les coins arrondis en CSS pour arrondir les photos

## La propriété background-image
https://developer.mozilla.org/fr/docs/Web/CSS/background-image

## La propriété padding
https://developer.mozilla.org/fr/docs/Web/CSS/padding

## La propriété max-width
https://developer.mozilla.org/fr/docs/Web/CSS/@viewport/max-width

## La propriété float
https://developer.mozilla.org/fr/docs/Web/CSS/float

## La propriété clear
https://developer.mozilla.org/fr/docs/Web/CSS/clear
http://fr.slideshare.net/jonathanpath/responsive-webdesign-devenir-un-rwd-master (page 7)
http://fr.learnlayout.com/clear.html

# INSTRUCTIONS
Révision et approfondissement du float et du inline-block

## HTML
- Utilisation du reset.css ou du normalize.css

## CSS
- Utilisation du inline-block et du float pour le placement de certains éléments
- Largeur limité à 1500px maximum
- Transparence du bloc d'entête : 0.75 uniquement pour le fond
- Utiliser une class pour limiter intelligememnt le contenu
- Taille de la police :
    - par défaut : 1em
    - titres h1 : 3em
    - titres h2 : 2em
- Police utilisés :
    - Titre : "Courgette"
    - Texte : "Open Sans"

## BONUS
- Trouver comment on intègre une google map

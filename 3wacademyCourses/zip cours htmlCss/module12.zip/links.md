## Les transitions en CSS
https://developer.mozilla.org/fr/docs/Web/CSS/transition

## Les effets de transitions en CSS
http://www.w3schools.com/cssref/tryit.asp?filename=trycss3_transition-timing-function2

## Les tranformations en CSS
https://developer.mozilla.org/fr/docs/Web/CSS/transform

## Le SVG
http://www.alsacreations.com/tuto/lire/1421-svg-initiation-syntaxe-outils.html

## Le canvas
http://www.alsacreations.com/tuto/lire/1484-introduction.html
https://openclassrooms.com/courses/dynamisez-vos-sites-web-avec-javascript/l-element-canvas

## Le multi-colonnage en CSS
http://www.alsacreations.com/tuto/lire/1557-les-multicolonnes-en-css3.html

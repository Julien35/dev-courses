# INSTRUCTIONS
Découverte du canvas, du SVG et des transitions CSS

## HTML
- Utilisation d'images en SVG
- Utilisation du canvas pour tracer le triangle

## CSS
- Utilisation des transitions et transformations en CSS
- Largeur limité à 1100px maximum
- Police utilisé : "Bree Serif"

## BONUS
- Trouver le moyen de faire un dégradé sur un background en CSS

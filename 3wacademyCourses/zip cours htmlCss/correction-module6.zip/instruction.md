# INSTRUCTIONS
Découverte des tableaux et des formulaires


## HTML
- Utilisation du normalize.css
- Utilisation des balises pour le tableau et pour les formulaires


## CSS
- Largeur limité à 1500px maximum
- Largeur du tableau : 90%
- Taille de la police :
    - On laisse les valeurs par défaut
- Police utilisés :
    - Titre : "Courgette"
    - Texte : "Open Sans"

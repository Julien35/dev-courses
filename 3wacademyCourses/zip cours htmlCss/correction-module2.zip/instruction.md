# INSTRUCTIONS
Comprendre le fonctionnement de la typographie sur le Web.

## HTML
- Utilisation des balises sémantiques basique

## CSS
- Largeur du site à 50%
- Police utilisé :
    - Titre : Special Elite
    - Texte : Cardo
- Taille de police :
    - h1 : 4em
    - h2 : 2.5em
    - h3 : 1.5em

## BONUS
Limiter la taille du contenu à 400px minimum

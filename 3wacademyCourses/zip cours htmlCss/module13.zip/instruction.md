# INSTRUCTIONS
Découverte du flexbox

## CSS
- Utilisation du flexbox
- Largeur limité à 80% maximum
- Taille de la police :
    - header h1 : 3em
    - header p : 2em
    - main h2 : 1.8em
    - main h3 : 1.2em
- Police utilisés :
    - Titre : "Candal"
    - Texte : "Open Sans"

## BONUS
- Réalisation de la version responsive

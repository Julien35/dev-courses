## INSTRUCTIONS
Découverte du positionnement en CSS

## HTML
- Utilisation du position absolute et du display none et block
- Utilisation des listes imbriquées pour l'intégralité de la navigation

# CSS
- utilisation des sélecteurs avancés

## BONUS
- Trouver comment on déclenche un effet au passage de la souris

# INSTRUCTIONS
Comprendre le fonctionnement de la typographie sur le Web.

## HTML
- Utilisation des balises sémantiques en priorité, les balises génériques viennent après

## CSS
- Largeur limité à 50%, 400px minimum

- Police utilisé :
    - Titre : Special Elite
    - Texte : Cardo


- Taille de police :
    - h1 : 4em
    - h2 : 2.5em / line-height : 1.2
    - h3 : 1.5em / line-height : 1
    - Première lettre : 2.7em


- Utilisation des pseudo éléments et des pseudo classes

- Rajouter les fleurons (les décoration de texte) ainsi que les quotes autour des citations
## ❧ ❦

## ASTUCE
Astuce pour voir la grille

    background-size: 100% 1.5em;
    background-image: -webkit-linear-gradient(#eee .05em, transparent 1px);
    background-image: -moz-linear-gradient(#eee .05em, transparent 1px);
    background-image: linear-gradient(#eee .05em, transparent 1px);

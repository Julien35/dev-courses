## INSTRUCTIONS
Découverte du responsive

## CSS
- Utilisation des media queries
- Utilisation du display none
- Largeur limité à 80% maximum
- Largeur du bloc de gauche en desktop : 70%
- Largeur du bloc de droite en desktop : 30%
- Police utilisés :
    - "PT Sans Narrow"
    - "Open Sans"
- Tailles utilisés :
    - titres h2 : 1.4em
    - nav : 1.6 em

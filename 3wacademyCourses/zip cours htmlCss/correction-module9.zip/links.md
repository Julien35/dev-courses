## Le préfixage en CSS
http://www.alsacreations.com/article/lire/1159-prefixes-vendeurs-css-proprietaires.html
http://pleeease.io/play/

## C'est quoi le Responsive WebDesign
http://www.alsacreations.com/article/lire/1615-cest-quoi-le-responsive-web-design.html

## Différentes tailles des écrans de device
http://mydevice.io/devices/

## Choisir la taille de sa police (et son unité) :
http://www.pompage.net/traduction/dimensionner-ses-fontes-avec-rem

## Les media queries
https://developer.mozilla.org/fr/docs/Web/CSS/Media_queries
http://www.alsacreations.com/article/lire/930-css3-media-queries.html

## Les coins arrondi
https://developer.mozilla.org/fr/docs/Web/CSS/border-radius

## Ombre portée
https://developer.mozilla.org/fr/docs/Web/CSS/box-shadow
https://developer.mozilla.org/fr/docs/Web/CSS/text-shadow

<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>Mini chat</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
<section>
	<article id="messages">
		<?php
			include('connexion.php');

			if (isset($_POST['pseudo']) AND $_POST['pseudo'] != '' AND isset($_POST['message']) AND $_POST['message'] != '') {

				$pseudo = htmlspecialchars($_POST['pseudo']);
				$_SESSION['pseudo'] = $pseudo;
				$message = htmlspecialchars($_POST['message']);
				$req = $bdd->prepare("INSERT INTO chat (pseudo, message, date_chat) VALUES (:pseudo, :message, :date_chat) ");
				$req->execute(array('pseudo' => $pseudo, 'message' => $message, 'date_chat' => date("Y-m-d H:i:s")));
				header('Location: index.php');

			}
			else{
				?>
				<p>Vous devez remplir tous les champs du formulaire !</p>
				<p><a href="index.php">Retour au formulaire.</a></p>
				<?php
			}
		?>
	</article>
</sectio>
</body>
</html>
	

<?php
	session_start();
	include('connexion.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>Mini chat</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
	<section>
		<article id="formulaire">
			<form action="chat.php" method="post">
				<p><input type="text" name="pseudo" value="<?php if(isset($_SESSION['pseudo'])){echo $_SESSION['pseudo'];}?>" id="pseudo" placeholder="Pseudo" /></p>
				<p><textarea name="message" id="message" placeholder="Message"></textarea></p>
				<p><input type="submit" value="Envoyer" name="envoyer" id="envoyer"/></p>
			</form>
		</article>
	</section>

	<section>
		<article id="messages">
			<h1>Messages</h1>
			<?php
			$reponse = $bdd->query("SELECT pseudo, message, DATE_FORMAT(date_chat, '%d/%m/%Y') AS date_chat FROM chat");
			while ($donnees = $reponse->fetch())
				{
			?>
			<p><span class="date">Le <?php echo $donnees['date_chat'];?></span> - <span class="pseudo"><?php echo $donnees['pseudo'];?></span> : <span class="message"><?php echo $donnees['message'];?></span></p>
			
			<p><span class="line"></span></p>
			<?php
				}

				$reponse->closeCursor();
			?>

		</article>
	</section>
</body>
</html>
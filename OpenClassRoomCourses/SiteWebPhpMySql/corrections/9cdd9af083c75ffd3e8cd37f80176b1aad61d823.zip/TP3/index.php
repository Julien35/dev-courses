<?php 
	session_start();
	
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Minichat</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
	<?php
		if(!empty($_SESSION['pseudo'])) {$pseudo = $_SESSION['pseudo'];} else {$pseudo = ""; } // test de $_SESSION
	?>
    <div class="message"> <!--mise en place du formulaire-->
        <form method="post" action="ajouter_message.php">
            <p><label for="pseudo"><em>Pseudo : </em></label><input type="text" name="pseudo" id="pseudo" value="<?php echo $pseudo;?>"><br/></p>
            <p><label for="message"><em>Message : </em></label><textarea name="message" id="message" rows="5" cols="45"></textarea><br/></p>
            <p><input type="submit" value="Envoyer"></p>
        </form>
    </div>
    <hr/>
    <div class="messages"> <!--la liste des messages decroissante-->
    	
    	<?php
			/*connecter la base de donnees*/ 
			include ("include/connection.php");
			/*chercher les message existants*/
			$reponse = $bdd->query('SELECT DATE_FORMAT(date_creation,\'%d/%m/%Y à %Hh%imin%ss\') AS date_creation_fr, pseudo, message FROM t_minichat ORDER BY date_creation DESC LIMIT 0,5');
			while($donnees = $reponse->fetch()) {
				?>
                    <p>
                    <em><?php echo htmlspecialchars($donnees['date_creation_fr']);?></em><br/>
                    <strong><?php echo htmlspecialchars($donnees['pseudo']);?></strong>
                    <?php echo htmlspecialchars($donnees['message']);?>
                    </p>
                <?php
			}
			
			$reponse->closeCursor();
		?>
        
    
    </div>
</body>
</html>
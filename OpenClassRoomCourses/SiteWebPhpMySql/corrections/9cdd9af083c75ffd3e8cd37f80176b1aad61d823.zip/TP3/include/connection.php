<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Connexion</title>
</head>

<body>
<?php 
		/* connecter la base de données*/
		try {
			$bdd = new PDO('mysql:host=localhost;dbname=test;charset=utf8','root','');
		}
		catch(Exception $e) {
			die('Erreur : '.$e->getMessage());
		}
?>
</body>
</html>
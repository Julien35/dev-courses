<?php 
	session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Ajouter un message</title>
</head>

<body>
<?php 
	/*TESTER LES VARIABLES POST*/
	if(!empty($_POST['pseudo']) && !empty($_POST['message'])) {
		/* AFFECTER LA VARIABLE DE SESSION*/
		$_SESSION['pseudo'] = $_POST['pseudo'];
		$pseudo = $_POST['pseudo'];
		$message = $_POST['message'];
		
		/* connecter la base de données*/
		include ("include/connection.php");
		
		/* inserer le nouveau message*/
		$req = $bdd->prepare('INSERT INTO t_minichat (pseudo, message, date_creation) VALUE(?,?,NOW())');
		$req->execute(array($pseudo, $message));
		
		/*fermer la requete*/
		$req->closeCursor();
		
		/*retour à la page idex*/
		header('location:index.php');		
	}
	else {
		/*retour à la page idex*/
		header('location:index.php');
	}

 ?>

</body>
</html>